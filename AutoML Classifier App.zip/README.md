
  # AutoML Classifier App

  This is a code bundle for AutoML Classifier App. The original project is available at https://www.figma.com/design/3EU7JujaToe996RkzAnUE2/AutoML-Classifier-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  