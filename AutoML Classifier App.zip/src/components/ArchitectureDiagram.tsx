import { Database, Cpu, Target, BarChart3, FileDown, GitCompare } from 'lucide-react';

export function ArchitectureDiagram() {
  return (
    <div className="bg-white rounded-lg shadow-lg p-8">
      <h2 className="text-gray-800 mb-8 text-center">System Architecture</h2>
      
      <div className="space-y-6">
        {/* Stage 1: Dataset */}
        <div className="flex items-center gap-4">
          <div className="flex-shrink-0 w-48 p-4 bg-blue-100 rounded-lg border-2 border-blue-300">
            <div className="flex items-center gap-2 justify-center">
              <Database className="w-5 h-5 text-blue-600" />
              <span className="text-blue-900">Dataset Input</span>
            </div>
          </div>
          <div className="flex-1 h-0.5 bg-gray-300"></div>
        </div>

        {/* Stage 2: Preprocessing */}
        <div className="flex items-center gap-4 pl-12">
          <div className="flex-1 h-0.5 bg-gray-300"></div>
          <div className="flex-shrink-0 w-56 p-4 bg-purple-100 rounded-lg border-2 border-purple-300">
            <div className="flex items-center gap-2 justify-center">
              <Cpu className="w-5 h-5 text-purple-600" />
              <span className="text-purple-900">Preprocessing</span>
            </div>
            <p className="text-purple-700 mt-1 text-center">
              Train/Val/Test Split
            </p>
          </div>
        </div>

        {/* Stage 3: Two Branches */}
        <div className="flex items-center gap-4 pl-24">
          <div className="flex-1 h-0.5 bg-gray-300 relative">
            <div className="absolute left-1/2 top-0 w-0.5 h-20 bg-gray-300 -translate-x-1/2"></div>
          </div>
        </div>

        {/* Branch 1: Baseline */}
        <div className="grid grid-cols-2 gap-8">
          <div className="space-y-4">
            <div className="p-4 bg-gray-100 rounded-lg border-2 border-gray-400">
              <div className="flex items-center gap-2 justify-center mb-2">
                <Target className="w-5 h-5 text-gray-600" />
                <span className="text-gray-900">Baseline GBM</span>
              </div>
              <p className="text-gray-700 text-center">
                Direct Training
              </p>
            </div>
            
            <div className="flex justify-center">
              <div className="w-0.5 h-12 bg-gray-300"></div>
            </div>
            
            <div className="p-3 bg-orange-50 rounded-lg border border-orange-200">
              <p className="text-orange-900 text-center">
                RandomizedSearchCV
              </p>
            </div>
          </div>

          {/* Branch 2: KPCA */}
          <div className="space-y-4">
            <div className="p-4 bg-green-100 rounded-lg border-2 border-green-400">
              <div className="flex items-center gap-2 justify-center mb-2">
                <Target className="w-5 h-5 text-green-600" />
                <span className="text-green-900">KPCA Pipeline</span>
              </div>
              <p className="text-green-700 text-center">
                RBF/Polynomial Kernel
              </p>
            </div>
            
            <div className="flex justify-center">
              <div className="w-0.5 h-12 bg-gray-300"></div>
            </div>
            
            <div className="p-3 bg-orange-50 rounded-lg border border-orange-200">
              <p className="text-orange-900 text-center">
                RandomizedSearchCV
              </p>
            </div>
          </div>
        </div>

        {/* Stage 4: Evaluation */}
        <div className="flex items-center gap-4 pl-24">
          <div className="flex-1 h-0.5 bg-gray-300 relative">
            <div className="absolute left-1/2 bottom-0 w-0.5 h-20 bg-gray-300 -translate-x-1/2"></div>
          </div>
        </div>

        <div className="flex items-center gap-4 pl-12">
          <div className="flex-1 h-0.5 bg-gray-300"></div>
          <div className="flex-shrink-0 w-56 p-4 bg-indigo-100 rounded-lg border-2 border-indigo-300">
            <div className="flex items-center gap-2 justify-center">
              <GitCompare className="w-5 h-5 text-indigo-600" />
              <span className="text-indigo-900">Evaluation</span>
            </div>
            <p className="text-indigo-700 mt-1 text-center">
              ROC-AUC, F1, Metrics
            </p>
          </div>
        </div>

        {/* Stage 5: Visualization */}
        <div className="flex items-center gap-4">
          <div className="flex-1 h-0.5 bg-gray-300"></div>
          <div className="flex-shrink-0 w-48 p-4 bg-pink-100 rounded-lg border-2 border-pink-300">
            <div className="flex items-center gap-2 justify-center">
              <BarChart3 className="w-5 h-5 text-pink-600" />
              <span className="text-pink-900">Visualization</span>
            </div>
          </div>
        </div>

        {/* Stage 6: Report */}
        <div className="flex items-center gap-4 pl-12">
          <div className="flex-1 h-0.5 bg-gray-300"></div>
          <div className="flex-shrink-0 w-56 p-4 bg-yellow-100 rounded-lg border-2 border-yellow-300">
            <div className="flex items-center gap-2 justify-center">
              <FileDown className="w-5 h-5 text-yellow-600" />
              <span className="text-yellow-900">Report Generation</span>
            </div>
          </div>
        </div>
      </div>

      {/* Legend */}
      <div className="mt-8 pt-6 border-t border-gray-200">
        <p className="text-gray-700 mb-3">Key Components:</p>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-blue-300 rounded"></div>
            <span className="text-gray-600">Data Input</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-gray-300 rounded"></div>
            <span className="text-gray-600">Baseline Model</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-green-300 rounded"></div>
            <span className="text-gray-600">KPCA Enhanced</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-orange-200 rounded"></div>
            <span className="text-gray-600">Optimization</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-indigo-300 rounded"></div>
            <span className="text-gray-600">Evaluation</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-pink-300 rounded"></div>
            <span className="text-gray-600">Output</span>
          </div>
        </div>
      </div>
    </div>
  );
}
