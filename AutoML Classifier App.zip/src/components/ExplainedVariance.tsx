import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Line, ComposedChart } from 'recharts';

interface ExplainedVarianceProps {
  variance: number[];
}

export function ExplainedVariance({ variance }: ExplainedVarianceProps) {
  let cumulative = 0;
  const data = variance.map((val, idx) => {
    cumulative += val;
    return {
      component: `PC${idx + 1}`,
      variance: val,
      cumulative: cumulative,
    };
  });

  const totalExplained = cumulative.toFixed(4);

  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <h3 className="text-gray-800 mb-4">Explained Variance by Principal Components</h3>
      <p className="text-gray-600 mb-4">
        Shows how much variance each principal component captures from the original feature space.
      </p>

      <ResponsiveContainer width="100%" height={400}>
        <ComposedChart data={data}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis
            dataKey="component"
            interval={4}
            label={{ value: 'Principal Component', position: 'insideBottom', offset: -5 }}
          />
          <YAxis
            yAxisId="left"
            label={{ value: 'Variance Ratio', angle: -90, position: 'insideLeft' }}
          />
          <YAxis
            yAxisId="right"
            orientation="right"
            label={{ value: 'Cumulative', angle: 90, position: 'insideRight' }}
            domain={[0, 1]}
          />
          <Tooltip
            formatter={(value: number) => value.toFixed(4)}
          />
          <Bar yAxisId="left" dataKey="variance" fill="#8b5cf6" />
          <Line
            yAxisId="right"
            type="monotone"
            dataKey="cumulative"
            stroke="#f59e0b"
            strokeWidth={2}
            dot={false}
          />
        </ComposedChart>
      </ResponsiveContainer>

      <div className="mt-4 grid grid-cols-2 gap-4">
        <div className="p-4 bg-purple-50 rounded-lg">
          <p className="text-purple-900">
            <span>Components Used:</span> 25
          </p>
        </div>
        <div className="p-4 bg-orange-50 rounded-lg">
          <p className="text-orange-900">
            <span>Total Variance Explained:</span> {totalExplained}
          </p>
        </div>
      </div>

      <div className="mt-4 p-4 bg-green-50 rounded-lg">
        <p className="text-green-900">
          <span>💡 Key Finding:</span> The first 25 components capture most of the variance,
          effectively reducing dimensionality while preserving critical information for classification.
        </p>
      </div>
    </div>
  );
}
