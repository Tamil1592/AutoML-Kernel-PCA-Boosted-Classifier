import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { ModelMetrics } from '../App';

interface ComparisonChartProps {
  baseline: ModelMetrics;
  kpca: ModelMetrics;
}

export function ComparisonChart({ baseline, kpca }: ComparisonChartProps) {
  const data = [
    {
      metric: 'AUC-ROC',
      Baseline: baseline.auc,
      'KPCA+GBM': kpca.auc,
    },
    {
      metric: 'F1-Score',
      Baseline: baseline.f1Score,
      'KPCA+GBM': kpca.f1Score,
    },
    {
      metric: 'Accuracy',
      Baseline: baseline.accuracy,
      'KPCA+GBM': kpca.accuracy,
    },
    {
      metric: 'Precision',
      Baseline: baseline.precision,
      'KPCA+GBM': kpca.precision,
    },
    {
      metric: 'Recall',
      Baseline: baseline.recall,
      'KPCA+GBM': kpca.recall,
    },
  ];

  const improvement = ((kpca.auc - baseline.auc) / baseline.auc * 100).toFixed(2);

  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <div className="mb-6">
        <h3 className="text-gray-800 mb-2">Model Performance Comparison</h3>
        <div className="flex items-center gap-4">
          <div className="px-4 py-2 bg-green-100 text-green-800 rounded-lg">
            AUC Improvement: +{improvement}%
          </div>
          <div className="px-4 py-2 bg-blue-100 text-blue-800 rounded-lg">
            Training Time Difference: +{(kpca.trainingTime - baseline.trainingTime).toFixed(2)}s
          </div>
        </div>
      </div>

      <ResponsiveContainer width="100%" height={400}>
        <BarChart data={data}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="metric" />
          <YAxis domain={[0, 1]} />
          <Tooltip formatter={(value: number) => value.toFixed(4)} />
          <Legend />
          <Bar dataKey="Baseline" fill="#64748b" />
          <Bar dataKey="KPCA+GBM" fill="#10b981" />
        </BarChart>
      </ResponsiveContainer>

      {/* Summary Table */}
      <div className="mt-6 overflow-x-auto">
        <table className="w-full">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-4 py-3 text-left text-gray-700">Metric</th>
              <th className="px-4 py-3 text-right text-gray-700">Baseline</th>
              <th className="px-4 py-3 text-right text-gray-700">KPCA+GBM</th>
              <th className="px-4 py-3 text-right text-gray-700">Improvement</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {data.map((row) => {
              const diff = ((row['KPCA+GBM'] - row.Baseline) / row.Baseline * 100);
              return (
                <tr key={row.metric}>
                  <td className="px-4 py-3 text-gray-900">{row.metric}</td>
                  <td className="px-4 py-3 text-right text-gray-700">
                    {row.Baseline.toFixed(4)}
                  </td>
                  <td className="px-4 py-3 text-right text-gray-700">
                    {row['KPCA+GBM'].toFixed(4)}
                  </td>
                  <td className={`px-4 py-3 text-right ${diff >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                    {diff >= 0 ? '+' : ''}{diff.toFixed(2)}%
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
