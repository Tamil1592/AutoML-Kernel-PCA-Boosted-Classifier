import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

interface ROCCurveProps {
  rocData: {
    baseline: { fpr: number[]; tpr: number[] };
    kpca: { fpr: number[]; tpr: number[] };
  };
}

export function ROCCurve({ rocData }: ROCCurveProps) {
  const chartData = rocData.baseline.fpr.map((fpr, idx) => ({
    fpr: fpr.toFixed(3),
    'Baseline TPR': rocData.baseline.tpr[idx],
    'KPCA+GBM TPR': rocData.kpca.tpr[idx],
    'Random': fpr,
  }));

  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <h3 className="text-gray-800 mb-4">ROC Curves</h3>
      <p className="text-gray-600 mb-4">
        Receiver Operating Characteristic curves showing the trade-off between true positive rate
        and false positive rate at various classification thresholds.
      </p>

      <ResponsiveContainer width="100%" height={400}>
        <LineChart data={chartData}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis
            dataKey="fpr"
            label={{ value: 'False Positive Rate', position: 'insideBottom', offset: -5 }}
          />
          <YAxis
            label={{ value: 'True Positive Rate', angle: -90, position: 'insideLeft' }}
          />
          <Tooltip />
          <Legend />
          <Line
            type="monotone"
            dataKey="Random"
            stroke="#94a3b8"
            strokeDasharray="5 5"
            dot={false}
          />
          <Line
            type="monotone"
            dataKey="Baseline TPR"
            stroke="#64748b"
            strokeWidth={2}
            dot={false}
          />
          <Line
            type="monotone"
            dataKey="KPCA+GBM TPR"
            stroke="#10b981"
            strokeWidth={2}
            dot={false}
          />
        </LineChart>
      </ResponsiveContainer>

      <div className="mt-4 p-4 bg-blue-50 rounded-lg">
        <p className="text-blue-900">
          <span>💡 Insight:</span> The KPCA-enhanced model shows a curve closer to the top-left
          corner, indicating better classification performance across all thresholds.
        </p>
      </div>
    </div>
  );
}
