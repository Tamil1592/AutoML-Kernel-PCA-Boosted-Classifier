import { TrendingUp, Clock, Target, Award } from 'lucide-react';
import { ModelMetrics } from '../App';

interface ModelResultsProps {
  title: string;
  subtitle: string;
  metrics: ModelMetrics;
  variant: 'enhanced' | 'baseline';
}

export function ModelResults({ title, subtitle, metrics, variant }: ModelResultsProps) {
  const gradientClass = variant === 'enhanced'
    ? 'from-emerald-500 to-green-500'
    : 'from-gray-500 to-slate-500';

  return (
    <div className="bg-white rounded-lg shadow-lg overflow-hidden">
      <div className={`bg-gradient-to-r ${gradientClass} text-white p-6`}>
        <h3>{title}</h3>
        <p className="text-white/90">{subtitle}</p>
      </div>

      <div className="p-6 space-y-4">
        {/* Primary Metrics */}
        <div className="grid grid-cols-2 gap-4">
          <div className="flex items-start gap-3">
            <div className="p-2 bg-purple-100 rounded-lg">
              <Award className="w-5 h-5 text-purple-600" />
            </div>
            <div>
              <p className="text-gray-500">AUC-ROC</p>
              <p className="text-gray-900">{metrics.auc.toFixed(4)}</p>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <div className="p-2 bg-blue-100 rounded-lg">
              <Target className="w-5 h-5 text-blue-600" />
            </div>
            <div>
              <p className="text-gray-500">F1-Score</p>
              <p className="text-gray-900">{metrics.f1Score.toFixed(4)}</p>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <div className="p-2 bg-green-100 rounded-lg">
              <TrendingUp className="w-5 h-5 text-green-600" />
            </div>
            <div>
              <p className="text-gray-500">Accuracy</p>
              <p className="text-gray-900">{metrics.accuracy.toFixed(4)}</p>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <div className="p-2 bg-orange-100 rounded-lg">
              <Clock className="w-5 h-5 text-orange-600" />
            </div>
            <div>
              <p className="text-gray-500">Training Time</p>
              <p className="text-gray-900">{metrics.trainingTime.toFixed(2)}s</p>
            </div>
          </div>
        </div>

        {/* Additional Metrics */}
        <div className="pt-4 border-t border-gray-200">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <p className="text-gray-500">Precision</p>
              <p className="text-gray-900">{metrics.precision.toFixed(4)}</p>
            </div>
            <div>
              <p className="text-gray-500">Recall</p>
              <p className="text-gray-900">{metrics.recall.toFixed(4)}</p>
            </div>
          </div>
        </div>

        {/* Hyperparameters */}
        <div className="pt-4 border-t border-gray-200">
          <p className="text-gray-700 mb-2">Best Hyperparameters</p>
          <div className="bg-gray-50 rounded-lg p-4 space-y-1">
            {Object.entries(metrics.hyperparameters).map(([key, value]) => (
              <div key={key} className="flex justify-between text-gray-700">
                <span className="text-gray-600">{key}:</span>
                <span>{typeof value === 'number' ? value.toFixed(4) : value}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
