import { Loader2 } from 'lucide-react';

interface ProgressBarProps {
  progress: number;
  stage: string;
}

export function ProgressBar({ progress, stage }: ProgressBarProps) {
  return (
    <div className="bg-white rounded-lg shadow-lg p-8 mb-8">
      <div className="flex items-center justify-center gap-3 mb-4">
        <Loader2 className="w-6 h-6 text-blue-600 animate-spin" />
        <h3 className="text-gray-800">Training Models...</h3>
      </div>

      <div className="mb-4">
        <div className="flex justify-between text-gray-600 mb-2">
          <span>{stage}</span>
          <span>{progress}%</span>
        </div>
        <div className="h-3 bg-gray-200 rounded-full overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-blue-500 via-purple-500 to-green-500 transition-all duration-500 ease-out"
            style={{ width: `${progress}%` }}
          />
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mt-6">
        <div className={`p-3 rounded-lg text-center ${progress >= 10 ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-500'}`}>
          <p>Preprocessing</p>
        </div>
        <div className={`p-3 rounded-lg text-center ${progress >= 30 ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-500'}`}>
          <p>Baseline</p>
        </div>
        <div className={`p-3 rounded-lg text-center ${progress >= 50 ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-500'}`}>
          <p>Tuning</p>
        </div>
        <div className={`p-3 rounded-lg text-center ${progress >= 80 ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-500'}`}>
          <p>KPCA Model</p>
        </div>
        <div className={`p-3 rounded-lg text-center ${progress >= 100 ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-500'}`}>
          <p>Evaluation</p>
        </div>
      </div>
    </div>
  );
}
