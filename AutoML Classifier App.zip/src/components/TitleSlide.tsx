import { GraduationCap, Mail, User } from 'lucide-react';

interface TitleSlideProps {
  onContinue: () => void;
}

export function TitleSlide({ onContinue }: TitleSlideProps) {
  return (
    <div className="fixed inset-0 bg-gradient-to-br from-blue-600 via-purple-600 to-indigo-700 flex items-center justify-center z-50">
      <div className="max-w-4xl mx-auto text-center px-8">
        {/* Main Title */}
        <div className="mb-12 animate-fade-in">
          <h1 className="text-white mb-6">
            AutoML Kernel PCA-Boosted
            <br />
            High-Dimensional Classifier
          </h1>
          <div className="h-1 w-32 bg-white mx-auto rounded-full"></div>
        </div>

        {/* Project Type Badge */}
        <div className="mb-12">
          <span className="inline-flex items-center gap-2 px-6 py-3 bg-white/20 backdrop-blur-sm text-white rounded-full border border-white/30">
            <GraduationCap className="w-5 h-5" />
            AI/ML Final Year Project
          </span>
        </div>

        {/* Developer Info */}
        <div className="bg-white/10 backdrop-blur-md rounded-2xl p-8 border border-white/20 shadow-2xl mb-12">
          <p className="text-white/80 mb-6">Developed by</p>
          
          <div className="space-y-4">
            <div className="flex items-center justify-center gap-3">
              <div className="p-2 bg-white/20 rounded-lg">
                <User className="w-6 h-6 text-white" />
              </div>
              <div className="text-left">
                <p className="text-white/70">Name</p>
                <p className="text-white">TAMILSELVAN. N</p>
              </div>
            </div>

            <div className="flex items-center justify-center gap-3">
              <div className="p-2 bg-white/20 rounded-lg">
                <Mail className="w-6 h-6 text-white" />
              </div>
              <div className="text-left">
                <p className="text-white/70">Email</p>
                <p className="text-white">selvants15092002@gmail.com</p>
              </div>
            </div>
          </div>
        </div>

        {/* Continue Button */}
        <button
          onClick={onContinue}
          className="px-12 py-4 bg-white text-blue-600 rounded-full hover:bg-blue-50 transition-all shadow-xl hover:shadow-2xl hover:scale-105"
        >
          Start Demo
        </button>

        {/* Footer */}
        <p className="text-white/50 mt-12">
          © 2025 | Advanced Machine Learning Project
        </p>
      </div>

      <style>{`
        @keyframes fade-in {
          from {
            opacity: 0;
            transform: translateY(-20px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        .animate-fade-in {
          animation: fade-in 1s ease-out;
        }
      `}</style>
    </div>
  );
}
