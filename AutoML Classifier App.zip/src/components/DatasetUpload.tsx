import { Upload } from 'lucide-react';
import { useRef } from 'react';

interface DatasetUploadProps {
  onUpload: (file: File) => void;
}

export function DatasetUpload({ onUpload }: DatasetUploadProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      onUpload(file);
    }
  };

  return (
    <>
      <input
        ref={fileInputRef}
        type="file"
        accept=".csv,.json,.txt"
        onChange={handleFileChange}
        className="hidden"
      />
      <button
        onClick={handleClick}
        className="flex items-center justify-center gap-3 p-6 bg-gradient-to-r from-blue-500 to-cyan-500 text-white rounded-lg hover:from-blue-600 hover:to-cyan-600 transition-all shadow-lg hover:shadow-xl"
      >
        <Upload className="w-6 h-6" />
        <span>Upload Dataset</span>
      </button>
    </>
  );
}
